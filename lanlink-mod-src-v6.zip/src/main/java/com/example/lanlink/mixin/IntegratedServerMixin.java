package com.example.lanlink.mixin;

import net.minecraft.server.integrated.IntegratedServer;
import net.minecraft.text.ClickEvent;
import net.minecraft.text.Style;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(IntegratedServer.class)
public class IntegratedServerMixin {
    @Inject(method = "openToLan", at = @At("RETURN"))
    private void onOpenToLan(net.minecraft.world.GameMode gameMode, boolean cheats, int port, CallbackInfoReturnable<Boolean> cir) {
        if (cir.getReturnValue()) {
            IntegratedServer server = (IntegratedServer) (Object) this;
            int serverPort = server.getServerPort();
            
            Text header = Text.literal("[LAN Link] Mundo aberto na porta: ")
                .formatted(Formatting.GREEN)
                .append(Text.literal(String.valueOf(serverPort)).formatted(Formatting.YELLOW, Formatting.BOLD));
                
            Text info = Text.literal("IP Local: 127.0.0.1:" + serverPort + " (Clique para copiar)")
                .setStyle(Style.EMPTY
                    .withColor(Formatting.AQUA)
                    .withClickEvent(new ClickEvent(ClickEvent.Action.COPY_TO_CLIPBOARD, "127.0.0.1:" + serverPort)));

            if (server.getPlayerManager() != null) {
                server.getPlayerManager().broadcast(header, false);
                server.getPlayerManager().broadcast(info, false);
            }
        }
    }
}
